HEX APPEAL - test build for the ZX Spectrum Next

Thanks for trying it. It's still being tuned, so expect changes.

On a real Next: copy the whole hexappeal folder to your SD card. Open it in the
Browser and pick hexappeal.nex. The other files must stay beside it: they are
the levels, the painted screens, the rivals' portraits and the speech.

In CSpect: give it this folder as its SD card, for example
  CSpect.exe -zxnext -w3 -esc -mmc=C:\games\hexappeal\ C:\games\hexappeal\hexappeal.nex
(-esc stops Escape closing the emulator.)

Playing:
- Q A O P, the cursor keys or a Kempston joystick to hop; SPACE fires.
- Hold fire on a glyph to use it: Seeing shows the map, Power blasts the room,
  Sorcery is the spell book (and saves your game), Travel takes you up or down.
- Hold fire anywhere else to cast your effect spell when EFF is green.
- Beat a rival magician in the duel: left and right pick a letter, fire swaps.
- H pauses (Q then quits to the title). K on the title sets your own keys.
  C on the title continues a saved game.
- A friend joins as Glim by pressing 2: the cursor keys and 0 to fire, or a
  second Kempston joystick.

Found a bug or have an idea? Tell us where you were and what happened.
https://mikeynma.github.io/hex-appeal/
